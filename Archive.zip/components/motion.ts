"use client";

// re-export ONLY the pieces you actually use
export {
  motion,
  AnimatePresence,
  LayoutGroup,
  useInView,
  useAnimation,
} from "framer-motion";
