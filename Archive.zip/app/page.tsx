"use client";

import { useState } from "react";
import { omit } from "lodash";
import SpendingForm from "@/components/SpendingForm";
import ResultsTable from "@/components/ResultsTable";
import { cards } from "@/lib/sampleData";
import { calculateCardValue, type CardResult } from "@/lib/rewardCalculator";

export default function Home() {
  const [results, setResults] = useState<CardResult[]>([]);

  return (
    <div className="space-y-8">
      <h1 className="text-3xl font-bold tracking-tight">CardOptimizer</h1>

      <SpendingForm
        onCalculate={(spend, prefs) => {
          /* merge the two pickers into one array the filters understand */
          const preferredPrograms = [
            ...prefs.preferredAirlines,
            ...prefs.preferredHotels,
          ];

          /* filter, score, and sort */
          const ranked = cards
            .filter((c) => c.annualFee <= prefs.maxAnnualFee)
            .filter(
              (c) =>
                preferredPrograms.length === 0 ||
                c.loyaltyPrograms.some((p) => preferredPrograms.includes(p)),
            )
            .map((card) => {
              /* run full calculation on the server-safe card */
              const raw = calculateCardValue(card, spend, {
                ...prefs,
                preferredPrograms, // not strictly needed by calc but harmless
              });

              /* strip live functions before they hit client state */
              const rs = raw.card.rewardStructure;
              const safeCard =
                rs.type === "special"
                  ? { ...raw.card, rewardStructure: omit(rs, "calc") }
                  : raw.card;

              return { ...raw, card: safeCard };
            })
            .sort((a, b) => b.netAnnual - a.netAnnual);

          setResults(ranked);
        }}
      />

      {results.length > 0 && <ResultsTable results={results} />}
    </div>
  );
}
